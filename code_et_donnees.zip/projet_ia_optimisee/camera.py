import cv2
import os

output_folder = 'data_test'
if not os.path.exists(output_folder):os.makedirs(output_folder)
cap = cv2.VideoCapture(0)
if not cap.isOpened():print("Erreur: la caméra ne peut pas être ouverte.");exit()
ret, frame = cap.read()
cap.release()
if not ret:print("Erreur: l'image n'a pas pu être capturée.")
else:output_path = os.path.join(output_folder, 'data_test.jpg');cv2.imwrite(output_path, frame);print(f"L'image a été sauvegardée sous {output_path}.")