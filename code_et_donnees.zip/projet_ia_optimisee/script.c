#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
    for(int i=0;i<10;i++){
        system("python3 camera.py");
        system("python3 test.py");
        sleep(1);
    }
    return 0;
}