import cv2
import numpy as np
import os
from collections import Counter
from scipy.spatial import distance
###########################################################################################
facteur_conversion=0.0264
def charge_image(folder, size=(64, 64)):
    images,labels,label_map = [],[],{}
    subfolders = [f for f in os.listdir(folder) if os.path.isdir(os.path.join(folder, f))]
    for label, subfolder in enumerate(subfolders):
        subfolder_path = os.path.join(folder, subfolder)
        label_map[label] = subfolder
        for filename in os.listdir(subfolder_path):
            img_path = os.path.join(subfolder_path, filename)
            try:
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                if img is None:print(f"Erreur de chargement de l'image {img_path}");continue
                img = cv2.resize(img, size) 
                img_array = img.flatten()
                images.append(img_array)
                labels.append(label)
            except Exception as e:print(f"Erreur lors du traitement de l'image {img_path}: {e}")
    return np.array(images), np.array(labels), label_map
def normlise_image(images):return images / 255.0
###########################################################################################
class Classeur_de_fruits:
    def __init__(self, k=3):self.k = k
    def fit(self, X, y):self.X_train = X;self.y_train = y
    def predict(self, X):
        predictions = []
        for x in X:
            distances = [distance.euclidean(x, x_train) for x_train in self.X_train]
            if len(distances) == 0:print("Aucune distance calculée.");predictions.append(-1);continue
            k_indices = np.argsort(distances)[:self.k]
            k_nearest_labels = [self.y_train[i] for i in k_indices]
            if not k_nearest_labels:print("Aucun label voisin trouvé.");predictions.append(-1);continue
            most_common = Counter(k_nearest_labels).most_common(1)
            if not most_common:print("Aucun label commun trouvé.");predictions.append(-1);continue
            predictions.append(most_common[0][0])
        return np.array(predictions)
def detecter_dimensions(img):
    contours, _ = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if len(contours) == 0:print("Aucun contour trouvé.");return None
    contour_principal = max(contours, key=cv2.contourArea)
    rect = cv2.minAreaRect(contour_principal)
    (x, y), (longueur_pixels, largeur_pixels), angle = rect
    longueur_cm = longueur_pixels * facteur_conversion
    largeur_cm = largeur_pixels * facteur_conversion
    rayon_cm = min(longueur_cm, largeur_cm) / 2  # On prend la plus petite dimension pour le rayon
    if longueur_cm > largeur_cm:return longueur_cm, rayon_cm
    else:return largeur_cm, rayon_cm
def predit_classe(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:raise ValueError(f"Erreur de chargement de l'image {image_path}")
    img_resized = cv2.resize(img, (64, 64))
    img_array = img_resized.flatten() / 255.0
    longueur_cm, rayon_cm = detecter_dimensions(img)
    if longueur_cm and rayon_cm:print(f"Dimensions détectées - Longueur: {longueur_cm:.2f} cm, Rayon: {rayon_cm:.2f} cm")
    else:print("Impossible de détecter les dimensions.")
    prediction = model.predict([img_array])
    return prediction[0], label_map.get(prediction[0], "Inconnu")
###########################################################################################
folder_path = 'dataset' 
X, y, label_map = charge_image(folder_path)
if len(X) == 0:raise ValueError("Aucune image valide n'a été chargée.")
X = normlise_image(X)
split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]
model = Classeur_de_fruits(k=3)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
if len(y_pred) == 0:raise ValueError("Aucune prédiction n'a été effectuée.")
accuracy = np.mean(y_pred == y_test)
image_test_path = '/home/david/projet_ia_optimisee/data_test/data_test.jpg'
try:result, label = predit_classe(image_test_path);print(f'Prédiction pour l\'image test : {label.replace("_"," ")}')
except ValueError as e:print(e)